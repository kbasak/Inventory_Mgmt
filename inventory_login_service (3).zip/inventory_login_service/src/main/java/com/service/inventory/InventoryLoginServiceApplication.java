package com.service.inventory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InventoryLoginServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(InventoryLoginServiceApplication.class, args);
	}

}
