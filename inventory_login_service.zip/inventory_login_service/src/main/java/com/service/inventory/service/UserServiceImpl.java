package com.service.inventory.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.service.inventory.entity.Users;
import com.service.inventory.repo.UserRepo;

@Service
public class UserServiceImpl implements UserService, UserDetailsService {

	@Autowired
	private UserRepo userRepo;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

		Users user = userRepo.findByUsername(username);
		
		if(user==null) {
			throw new UsernameNotFoundException("User not found for email: "+username);
		}
		return new org.springframework.security.core.userdetails.User
				(user.getUsername(), user.getPassword(), user.getRoles());
	}

	@Override
	public Users saveUsers(Users users) {
		Users value = userRepo.save(users);
		return value;
	}

	@Override
	public boolean existByUsername(String username) {
		return userRepo.existsByUsername(username);
	}

}
