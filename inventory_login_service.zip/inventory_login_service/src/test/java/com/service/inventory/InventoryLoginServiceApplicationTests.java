package com.service.inventory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InventoryLoginServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
